"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const objectchecker = {
    isNilOrUndefined: (object) => object == null || object == undefined
};
exports.default = objectchecker;
