"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CasesController = void 0;
const message_1 = require("../utils/message");
const longrunningreq_1 = require("../cases/longrunningreq");
const objectchecker_1 = require("../utils/objectchecker");
class CasesController {
    constructor() {
        this.DEFAULT_WAIT_TIME = 2000;
    }
    /**
     * Wait for a request to be done
     * @param event
     */
    waitForResponse(event, context) {
        return __awaiter(this, void 0, void 0, function* () {
            // The amount of memory allocated for the function
            console.log('memoryLimitInMB: ', context.memoryLimitInMB);
            const wait = Number(objectchecker_1.default.isNilOrUndefined(event.queryStringParameters) || objectchecker_1.default.isNilOrUndefined(event.queryStringParameters.wait) ?
                this.DEFAULT_WAIT_TIME : event.queryStringParameters.wait);
            try {
                const resp = longrunningreq_1.default(wait);
                return message_1.default.success({ msg: `i waited for you for ${wait}` });
            }
            catch (err) {
                console.error(err);
                return message_1.default.error(err.code, err.message);
            }
        });
    }
}
exports.CasesController = CasesController;
