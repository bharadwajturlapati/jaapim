"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wait = void 0;
const cases_1 = require("../controller/cases");
exports.wait = (event, context) => {
    return new cases_1.CasesController().waitForResponse(event, context);
};
